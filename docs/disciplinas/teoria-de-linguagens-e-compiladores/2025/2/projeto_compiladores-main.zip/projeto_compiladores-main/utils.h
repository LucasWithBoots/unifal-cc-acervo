/*+=============================================================
| UNIFAL = Universidade Federal de Alfenas.
| BACHARELADO EM CIENCIA DA COMPUTACAO.
| Trabalho . . : Construcao Arvore Sintatica e Geracao de Codigo
| Disciplina . : Teoria de Linguagens e Compiladores
| Professor . .: Luiz Eduardo da Silva
| Aluno . . . .: Lucas Carrijo Ferrari
| Data . . . . : 25/11/2025
+=============================================================*/

#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>

#define TAM_TAB 100

enum
{
    INT,
    LOG
};

typedef struct
{
    char id[100];
    int end;
    int tip;
} elemTabSimb;

extern elemTabSimb tabSimb[TAM_TAB];
extern int topoTab;
extern elemTabSimb elemTab;

void insereSimbolo(elemTabSimb elem);
int buscaSimbolo(char *id);

#define TAM_PIL 100

extern int Pilha[TAM_PIL];
extern int topo;

void empilha(int valor);
int desempilha(void);
void testaTipo(int tipo1, int tipo2, int ret);

#endif
