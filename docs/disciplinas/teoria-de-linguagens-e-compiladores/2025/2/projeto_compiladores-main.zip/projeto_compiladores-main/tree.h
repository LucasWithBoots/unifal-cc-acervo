/*+=============================================================
| UNIFAL = Universidade Federal de Alfenas.
| BACHARELADO EM CIENCIA DA COMPUTACAO.
| Trabalho . . : Construcao Arvore Sintatica e Geracao de Codigo
| Disciplina . : Teoria de Linguagens e Compiladores
| Professor . .: Luiz Eduardo da Silva
| Aluno . . . .: Lucas Carrijo Ferrari
| Data . . . . : 25/11/2025
+=============================================================*/

#ifndef TREE_H
#define TREE_H

#include "utils.h"

typedef struct no *ptno;

typedef enum
{
    N_PROG,
    N_IDENT,
    N_DECLS,
    N_DECL,
    N_TIPO,
    N_LVAR,
    N_VAR,
    N_LISTA_CMD,
    N_LEIA,
    N_ESCREVA,
    N_ATRIB,
    N_ENQTO,
    N_SE,
    N_SENAO,
    N_SOMA,
    N_SUB,
    N_MULT,
    N_DIV,
    N_MAIOR,
    N_MENOR,
    N_IGUAL,
    N_E,
    N_OU,
    N_NAO,
    N_NUM,
    N_LOGICO
} TipoNo;

struct no
{
    int tipo;
    int valor;
    char texto[64];
    ptno filho;
    ptno irmao;
};

ptno criaNo(int tipo, const char *texto, int valor);
void adicionaFilho(ptno pai, ptno filho);
ptno juntaFilhos(ptno primeiro, ptno resto);
void mostra(ptno raiz, int nivel);
void geraDot(ptno raiz, const char *basename);
void geraCodigo(ptno raiz, FILE *out);

#endif
