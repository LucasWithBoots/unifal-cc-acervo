/*+=============================================================
| UNIFAL = Universidade Federal de Alfenas.
| BACHARELADO EM CIENCIA DA COMPUTACAO.
| Trabalho . . : Construcao Arvore Sintatica e Geracao de Codigo
| Disciplina . : Teoria de Linguagens e Compiladores
| Professor . .: Luiz Eduardo da Silva
| Aluno . . . .: Lucas Carrijo Ferrari
| Data . . . . : 25/11/2025
+=============================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tree.h"

extern int contaVar;
extern int rotulo;
extern void yyerror(char *);

static void geraNos(FILE *f, ptno raiz);
static void geraLigacoes(FILE *f, ptno raiz);
static void geraLista(ptno lista, FILE *out);
static int geraExpressao(ptno p, FILE *out);
static void geraComando(ptno p, FILE *out);

ptno criaNo(int tipo, const char *texto, int valor)
{
    ptno n = (ptno)malloc(sizeof(struct no));
    if (!n)
    {
        perror("Falha ao alocar no");
        exit(1);
    }
    n->tipo = tipo;
    n->valor = valor;
    strncpy(n->texto, texto ? texto : "", sizeof(n->texto) - 1);
    n->texto[sizeof(n->texto) - 1] = '\0';
    n->filho = NULL;
    n->irmao = NULL;
    return n;
}

void adicionaFilho(ptno pai, ptno filho)
{
    if (!pai || !filho)
        return;

    if (!pai->filho)
    {
        pai->filho = filho;
    }
    else
    {
        ptno p = pai->filho;
        while (p->irmao)
            p = p->irmao;
        p->irmao = filho;
    }
}

ptno juntaFilhos(ptno primeiro, ptno resto)
{
    if (!primeiro)
        return resto;
    ptno p = primeiro;
    while (p->irmao)
        p = p->irmao;
    p->irmao = resto;
    return primeiro;
}

void mostra(ptno raiz, int nivel)
{
    if (!raiz)
        return;

    for (int i = 0; i < nivel; i++)
        printf("\t");
    printf("[%s|%d]\n", raiz->texto, raiz->valor);
    for (ptno p = raiz->filho; p; p = p->irmao)
    {
        mostra(p, nivel + 1);
    }
}

static void geraNos(FILE *f, ptno raiz)
{
    if (!raiz)
        return;

    fprintf(f, "\tn%p [label=\"%s|%d\"]\n", (void *)raiz, raiz->texto, raiz->valor);
    for (ptno p = raiz->filho; p; p = p->irmao)
    {
        geraNos(f, p);
    }
}

static void geraLigacoes(FILE *f, ptno raiz)
{
    if (!raiz)
        return;

    for (ptno p = raiz->filho; p; p = p->irmao)
    {
        fprintf(f, "\tn%p -> n%p\n", (void *)raiz, (void *)p);
        geraLigacoes(f, p);
    }
}

void geraDot(ptno raiz, const char *basename)
{
    char nomeDot[128];
    snprintf(nomeDot, sizeof(nomeDot), "%s.dot", basename);

    FILE *f = fopen(nomeDot, "wt");
    if (!f)
    {
        perror("Falha ao criar arquivo DOT");
        return;
    }

    fprintf(f, "digraph {\n");
    fprintf(f, "\tnode [shape=record , height = .1];\n");
    geraNos(f, raiz);
    geraLigacoes(f, raiz);
    fprintf(f, "}\n");
    fclose(f);
}

static void geraDeclaracoes(ptno p, FILE *out)
{
    (void)out;
    while (p)
    {
        p = p->irmao;
    }
}

static void geraLista(ptno lista, FILE *out)
{
    ptno p = lista;
    while (p)
    {
        geraComando(p, out);
        p = p->irmao;
    }
}

static int geraExpressao(ptno p, FILE *out)
{
    if (!p)
        return INT;

    ptno p1, p2;
    switch (p->tipo)
    {
    case N_IDENT:
        fprintf(out, "\tCRVG\t%d\n", tabSimb[p->valor].end);
        return tabSimb[p->valor].tip;
    case N_NUM:
        fprintf(out, "\tCRCT\t%d\n", p->valor);
        return INT;
    case N_LOGICO:
        fprintf(out, "\tCRCT\t%d\n", p->valor);
        return LOG;
    case N_NAO:
        p1 = p->filho;
        if (geraExpressao(p1, out) != LOG)
            yyerror("Erro: operador logico esperado\n");
        fprintf(out, "\tNEGA\n");
        return LOG;
    case N_SOMA:
        p1 = p->filho;
        p2 = p1->irmao;
        if (geraExpressao(p1, out) != INT || geraExpressao(p2, out) != INT)
            yyerror("Erro: soma espera inteiros\n");
        fprintf(out, "\tSOMA\n");
        return INT;
    case N_SUB:
        p1 = p->filho;
        p2 = p1->irmao;
        if (geraExpressao(p1, out) != INT || geraExpressao(p2, out) != INT)
            yyerror("Erro: subtracao espera inteiros\n");
        fprintf(out, "\tSUBT\n");
        return INT;
    case N_MULT:
        p1 = p->filho;
        p2 = p1->irmao;
        if (geraExpressao(p1, out) != INT || geraExpressao(p2, out) != INT)
            yyerror("Erro: multiplicacao espera inteiros\n");
        fprintf(out, "\tMULT\n");
        return INT;
    case N_DIV:
        p1 = p->filho;
        p2 = p1->irmao;
        if (geraExpressao(p1, out) != INT || geraExpressao(p2, out) != INT)
            yyerror("Erro: divisao espera inteiros\n");
        fprintf(out, "\tDIVI\n");
        return INT;
    case N_MAIOR:
        p1 = p->filho;
        p2 = p1->irmao;
        if (geraExpressao(p1, out) != INT || geraExpressao(p2, out) != INT)
            yyerror("Erro: comparacao maior espera inteiros\n");
        fprintf(out, "\tCMMA\n");
        return LOG;
    case N_MENOR:
        p1 = p->filho;
        p2 = p1->irmao;
        if (geraExpressao(p1, out) != INT || geraExpressao(p2, out) != INT)
            yyerror("Erro: comparacao menor espera inteiros\n");
        fprintf(out, "\tCMME\n");
        return LOG;
    case N_IGUAL:
        p1 = p->filho;
        p2 = p1->irmao;
        if (geraExpressao(p1, out) != INT || geraExpressao(p2, out) != INT)
            yyerror("Erro: comparacao igual espera inteiros\n");
        fprintf(out, "\tCMIG\n");
        return LOG;
    case N_E:
        p1 = p->filho;
        p2 = p1->irmao;
        if (geraExpressao(p1, out) != LOG || geraExpressao(p2, out) != LOG)
            yyerror("Erro: operador 'e' espera logicos\n");
        fprintf(out, "\tCONJ\n");
        return LOG;
    case N_OU:
        p1 = p->filho;
        p2 = p1->irmao;
        if (geraExpressao(p1, out) != LOG || geraExpressao(p2, out) != LOG)
            yyerror("Erro: operador 'ou' espera logicos\n");
        fprintf(out, "\tDISJ\n");
        return LOG;
    default:
        return INT;
    }
}

static void geraComando(ptno p, FILE *out)
{
    if (!p)
        return;

    ptno p1, p2, p3;
    switch (p->tipo)
    {
    case N_LEIA:
        p1 = p->filho;
        fprintf(out, "\tLEIA\n");
        fprintf(out, "\tARZG\t%d\n", tabSimb[p1->valor].end);
        break;
    case N_ESCREVA:
        p1 = p->filho;
        geraExpressao(p1, out);
        fprintf(out, "\tESCR\n");
        break;
    case N_ATRIB:
        p1 = p->filho;
        p2 = p1->irmao;
        if (geraExpressao(p2, out) != tabSimb[p1->valor].tip)
        {
            yyerror("Erro: tipo incompatível na atribuicao\n");
        }
        fprintf(out, "\tARZG\t%d\n", tabSimb[p1->valor].end);
        break;
    case N_ENQTO:
        p1 = p->filho;       /* condicao */
        p2 = p1->irmao;      /* corpo */
        fprintf(out, "L%d\tNADA\n", ++rotulo);
        int inicio = rotulo;
        if (geraExpressao(p1, out) != LOG)
            yyerror("Erro: expressao logica esperada em ENQTO\n");
        fprintf(out, "\tDSVF\tL%d\n", ++rotulo);
        int fim = rotulo;
        geraLista(p2 ? p2->filho : NULL, out);
        fprintf(out, "\tDSVS\tL%d\n", inicio);
        fprintf(out, "L%d\tNADA\n", fim);
        break;
    case N_SE:
        p1 = p->filho;           /* cond */
        p2 = p1->irmao;          /* entao */
        p3 = p2->irmao;          /* senao */
        if (geraExpressao(p1, out) != LOG)
            yyerror("Erro: expressao logica esperada em SE\n");
        fprintf(out, "\tDSVF\tL%d\n", ++rotulo);
        int rotSenao = rotulo;
        geraLista(p2 ? p2->filho : NULL, out);
        fprintf(out, "\tDSVS\tL%d\n", ++rotulo);
        int rotFim = rotulo;
        fprintf(out, "L%d\tNADA\n", rotSenao);
        geraLista((p3 && p3->filho) ? p3->filho : NULL, out);
        fprintf(out, "L%d\tNADA\n", rotFim);
        break;
    default:
        geraLista(p->filho, out);
        break;
    }
}

void geraCodigo(ptno raiz, FILE *out)
{
    if (!raiz)
        return;

    fprintf(out, "\tINPP\n");
    fprintf(out, "\tAMEM\t%d\n", contaVar);

    ptno decls = raiz->filho ? raiz->filho->irmao : NULL;
    ptno comandos = decls ? decls->irmao : NULL;

    geraDeclaracoes(decls ? decls->filho : NULL, out);
    geraLista(comandos ? comandos->filho : NULL, out);

    fprintf(out, "\tDMEM\t%d\n", contaVar);
    fprintf(out, "\tFIMP\n");
}
