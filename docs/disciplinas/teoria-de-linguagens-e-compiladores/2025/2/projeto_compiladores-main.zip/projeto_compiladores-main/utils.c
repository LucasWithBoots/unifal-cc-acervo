/*+=============================================================
| UNIFAL = Universidade Federal de Alfenas.
| BACHARELADO EM CIENCIA DA COMPUTACAO.
| Trabalho . . : Construcao Arvore Sintatica e Geracao de Codigo
| Disciplina . : Teoria de Linguagens e Compiladores
| Professor . .: Luiz Eduardo da Silva
| Aluno . . . .: Lucas Carrijo Ferrari
| Data . . . . : 25/11/2025
+=============================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "utils.h"

extern void yyerror(char *);

elemTabSimb tabSimb[TAM_TAB], elemTab;
int topoTab = 0;

void insereSimbolo(elemTabSimb elem)
{
    int i;
    if (topoTab == TAM_TAB)
    {
        yyerror("Erro: Tabela de símbolos cheia\n");
    }
    for (i = topoTab - 1; i >= 0 && strcmp(tabSimb[i].id, elem.id) && i >= 0; i--)
        ;

    if (i != -1)
    {
        char msg[200];
        sprintf(msg, "Erro: símbolo %s já declarado\n", elem.id);
        yyerror(msg);
    }

    tabSimb[topoTab++] = elem;
}

int buscaSimbolo(char *id)
{
    int i;
    if (topoTab == 0)
    {
        yyerror("Não existem identificadores cadastrados");
    }
    for (i = topoTab - 1; i >= 0 && strcmp(tabSimb[i].id, id); i--)
        ;

    if (i == -1)
    {
        char msg[200];
        sprintf(msg, "O identificador [%s] não foi encontrado\n", id);
        yyerror(msg);
    }

    return i;
}

// ------------------- PILHA -------------------

int Pilha[TAM_PIL];
int topo = -1;

void empilha(int valor)
{
    if (topo == TAM_PIL - 1)
    {
        yyerror("Erro: Pilha cheia\n");
    }
    Pilha[++topo] = valor;
}

int desempilha(void)
{
    if (topo == -1)
    {
        yyerror("Erro: Pilha vazia\n");
    }
    return Pilha[topo--];
}

void testaTipo(int tipo1, int tipo2, int ret)
{
    int t2 = desempilha();
    int t1 = desempilha();
    if (t1 != tipo1 || t2 != tipo2)
    {
        yyerror("Erro: tipos incompatíveis\n");
    }
    empilha(ret);
}
